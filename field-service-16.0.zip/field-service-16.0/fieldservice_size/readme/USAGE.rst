## Enter sizes for field service locations.
Go to Master Data > Locations

#. Select or create a location.
#. Go to the Sizes tab.
#. Select a Size. Enter the value for the size.

## Use Order Sizes

#. Select or create a field service order.
#. Set a location on the order.
#. Set a type on the order.
#. The size value will update to the location's size
   value of the order type's default size.
