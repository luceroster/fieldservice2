* Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
* Nikul Chaudhary <nikul.chaudhary.serpentcs@gmail.com>
* Freni Patel <fpatel@opensourceintegrators.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
