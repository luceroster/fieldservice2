To use this module, you need to:

* Go to Field Service > Configuration > Stages
* Define the workflow of your routes by creating new stages whose type is "Route"
* Go to Field Service > Master Data > Routes
* Create your routes by setting their name and selecting their territory
