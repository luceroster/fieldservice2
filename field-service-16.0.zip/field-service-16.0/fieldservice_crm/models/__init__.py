# Copyright (C) 2019, Patrick Wilson
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import crm_lead
from . import fsm_location
from . import fsm_order
