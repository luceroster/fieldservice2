* Go to Field Service > Configuration > Stages
* Create or select a stage
* Select one or more fields to be validated
