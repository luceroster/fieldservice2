To use this module, you need to:

* In fieldservice app go to Menu > Operations > Recurring Orders
* Create a new Recurring Order model
* Select a Recurring Template and modify as needed.
* Set other fields for fsm location, etc
* Confirm the recurrence to create first order
* Future orders will be created via cron task
