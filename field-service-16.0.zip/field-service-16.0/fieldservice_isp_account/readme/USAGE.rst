To use the module:

On a field service order, open the "Accounting" tab. Depending on
whether the logged in user or an employee or not, they will see
either a place to enter timesheet records or contractor costs.

The total cost of the order is calculated based on the entries in
the employee timesheet entries and contractor costs.

When an order is completed, a customer invoice will be generated for
the employee time and the contractor costs. A vendor bill will be
created for the contractor costs.
