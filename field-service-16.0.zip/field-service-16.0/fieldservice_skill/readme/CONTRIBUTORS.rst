* Wolfgang Hall <whall@opensourceintegrators.com>
* Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
* Steve Campbell <scampbell@opensourceintegrators.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Brian McMaster <brian@mcmpest.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Stefan Ungureanu
