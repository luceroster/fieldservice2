To use this module, you need to:

* Create an order, set the template and the location

  * The categories and skills are set based on the template.
  * The field service worker is set to the preferred worker if skills matches.
  * The list of field service workers is filtered with the one serving the
    location and having the skills
