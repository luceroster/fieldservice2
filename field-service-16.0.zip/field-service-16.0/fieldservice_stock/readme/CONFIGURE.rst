To configure this module, you need to:

* Go to Field Service > Master Data > Locations
* Create or select a location and set the inventory location

If you are in a multi-warehouse situation:

* Go to Field Service > Configuration > Territories
* Create or select a territory
* Set the warehouse that will serve this territory
