This module primarily establishes a connection between stock and
field service operations so therefore has no specific usage
instructions.
