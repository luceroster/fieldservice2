This module is an add-on for the Field Service application in Odoo.
It provides a generic framework to allow you to link inventory and
stock operations with your field service operations.
