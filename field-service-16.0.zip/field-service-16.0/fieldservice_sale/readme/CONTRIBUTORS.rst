* Open Source Integrators <https://opensourceintegrators.com>

  * Steve Campbell <scampbell@opensourceintegrators.com>
  * Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
  * Wolfgang Hall <whall@opensourceintegrators.com>
  * Raphael Lee <rlee@opensourceintegrators.com>

* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Brian McMaster <brian@mcmpest.com>
* Rapha??l Reverdy <raphael.reverdy@akretion.com>
* Cl??ment Mombereau <clement.mombereau@akretion.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Stefan Ungureanu
