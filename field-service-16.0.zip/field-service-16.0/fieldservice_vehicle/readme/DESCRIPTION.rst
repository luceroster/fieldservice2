This module allows you to manage your vehicles and assign them to a worker.
