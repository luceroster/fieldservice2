To use this module, you need to:

* Go to Field Service
* Create or select an order and assign it
* Follow the process
