To configure this module, you need to:

* Go to Field Service > Master Data > Vehicles
* Create your vehicles and assign them to a worker
